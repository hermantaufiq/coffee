# My Protofolio Website
This is the repo for the my personal website. I added some interaction and basic functionalities in this website. 

The `v1.0.0` represent the most stable `frontend only` version of this website. Later in `v2.0.0`, I added authentication system, dashboard etc. The `v2.0.0` is the edition of `v1.0.0` using `PHP` and `MySQL` database.

### #100DaysOfCode