<div class="my-skills padding" id="my-skill">
    <div class="container">
      <h1 class="text-primary text-center heading wow fadeInUp">Top Skills</h1>
      <ul>
        <a href="#">
          <li>
            <h3 class="text-light">Geographic Information System (GIS)</h3>
          </li>
        </a>
        <a href="#">
          <li>
            <h3 class="text-light">Python</h3>
          </li>
        </a>
        <a href="#">
          <li>
            <h3 class="text-light">Django</h3>
          </li>
        </a>
        <a href="#">
          <li>
            <h3 class="text-light">JavaScript</h3>
          </li>
        </a>
        <a href="#">
          <li>
            <h3 class="text-light">Leaflet</h3>
          </li>
        </a>
        <a href="#">
          <li>
            <h3 class="text-light">HTML/CSS/Bootstrap</h3>
          </li>
        </a>
        <a href="#">
          <li>
            <h3 class="text-light">Git and Github</h3>
          </li>
        </a>
        <a href="#">
          <li>
            <h3 class="text-light">Remote Sensing</h3>
          </li>
        </a>
      </ul>
    </div>
  </div>