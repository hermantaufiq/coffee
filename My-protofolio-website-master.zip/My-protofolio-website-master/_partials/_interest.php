<!--My Interests-->
<div class="container-fluid bg-dark my-interests padding" id="interest">
    <h1 class="text-primary text-center heading wow fadeInUp">Interests</h1>

    <div class="row">
      <div class="col-md-2 col-sm-4 text-center wow fadeInUp" data-wow-delay=".5s">
        <i class="fas fa-code text-success padding"></i>
        <p class="my-interests-1 text-white">CODING</p>
      </div>

      <div class="col-md-2 col-sm-4 text-center wow fadeInUp" data-wow-delay=".5s">
        <i class="fa fa-camera text-success padding" aria-hidden="true"></i>
        <p class="my-interests-1 text-white">PHOTOGRAPHY</p>
      </div>

      <div class="col-md-2 col-sm-4 text-center wow fadeInUp" data-wow-delay=".5s">
        <i class="fa fa-plane text-success padding" aria-hidden="true"></i>
        <p class="my-interests-1 text-white">TRAVELLING</p>
      </div>

      <div class="col-md-2 col-sm-4 text-center wow fadeInUp" data-wow-delay=".5s">
        <i class="fa fa-book text-success padding" aria-hidden="true"></i>
        <p class="my-interests-1 text-white">READING</p>
      </div>

      <div class="col-md-2 col-sm-4 text-center wow fadeInUp" data-wow-delay=".5s">
        <i class="fa fa-gamepad text-success padding" aria-hidden="true"></i>
        <p class="my-interests-1 text-white">GAMING</p>
      </div>

      <div class="col-md-2 col-sm-4 text-center wow fadeInUp" data-wow-delay=".5s">
        <i class="fa fa-music text-success padding" aria-hidden="true"></i>
        <p class="my-interests-1 text-white">MUSIC</p>
      </div>

    </div>

  </div>

  </div>
