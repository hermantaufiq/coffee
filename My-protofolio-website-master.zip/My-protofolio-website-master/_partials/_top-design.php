<!--Main content-->
<div class="container-fluid main-1" id="top">
    <div class="main-2">
      <h3 class="text-light wow fadeInUp" data-wow-duration=".7s" data-wow-delay=".5s">I am</h3>
      <h1 class="text-white wow bounceInLeft" data-wow-duration="2s" data-wow-delay="1s">Tek Bahadur Kshetri</h1>
      <p class="text-muted wow bounceInRight" data-wow-duration="2s" data-wow-delay="1s"><i>Student of Geomatics
          Engineering</i></p>
      <a href="#my-self" class="btn btn-primary wow fadeIn" data-wow-duration="2s" data-wow-delay="2s">Know More</a>
    </div>
</div>