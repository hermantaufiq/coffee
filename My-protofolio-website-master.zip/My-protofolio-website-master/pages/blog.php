<!-- blog main  -->
<div class="blog padding">
    <div>
        <h1 class="col-12 text-primary text-center heading padding wow fadeInUp">My Blog</h1>
        <div class="not-reached"><b>Sorry! </b> No blog is published yet</div>
    </div>
</div>