<!-- research main content -->
<div class="research padding">
    <div>
        <h1 class="col-12 text-primary text-center heading padding wow fadeInUp">My Research</h1>
        <div class="not-reached"><b>Sorry! </b> No research is published yet</div>
    </div>
</div>

